library(tidyverse)
library(here)
library(lamadex, lib("./lamadex/lamadex"))
here()


#----------
# Load data
## read in country lists according to the World Bank Lending Groups classification
source("./lamadex/R/source/countryList.R") # stored lists: [1]: LICs (30) [2]: LMICs (46) [3]: LICs+LMICs (76) [4]: All countries (244)

## read in dataframes from raw csv files
source("./lamadex/R/source/data_loader.R")

#----------
# Run the package

rank <- rank_generator(dfList, country_lists[[3]], bygender = "Total", lastyear = 2010, impute = TRUE) %>%
  arrange(desc(index_mean))

#write.csv(rank, here()Desktop/total_raw.csv")

#----------
# Clean up
##rank <- rank %>%
##  filter(!is.na(index_mean)) ## remove unranked countries

## rm(country_lists, dfList, neet, unemployment_rate, employed, unemployed, working_pov, underemp, informal, status, occupation, education, literacy, test_scores)


